package com.kamelsoft.telecombills;
import java.util.Scanner;
public class TelecomBills {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the initial load amount (UGX): ");
        double initialLoadAmount = scanner.nextDouble();
        
        System.out.print("Enter the charge percentage (e.g., 10 for 10%): ");
        double chargePercentage = scanner.nextDouble() / 100; 
        
        System.out.print("Enter the call cost per second (UGX): ");
        int callCostPerSecond = scanner.nextInt();
        
        System.out.print("Enter the call duration in minutes: ");
        int callDurationMinutes = scanner.nextInt();
        final int SECONDSINMINUTE = 60;
        double chargeAmount = initialLoadAmount * chargePercentage;
        double initialBalance = initialLoadAmount - chargeAmount;
        int callDurationSeconds = callDurationMinutes * SECONDSINMINUTE;
    
        double callCost = callCostPerSecond * callDurationSeconds;

        double finalBalance = initialBalance - callCost;

        System.out.println("\nInitial balance after system charge: UGX " + initialBalance);
        System.out.println("Total cost of the call: UGX " + callCost);
        System.out.println("Final balance after the call: UGX " + finalBalance);

        scanner.close();
    }
}
